# Notes

## What went wrong first
I applied the ACL on the wrong interface and HTTP traffic was not blocked.

## Fix
Move the ACL closer to the source and verify the direction.

## Verification
- Ping still works
- Web traffic fails as expected
