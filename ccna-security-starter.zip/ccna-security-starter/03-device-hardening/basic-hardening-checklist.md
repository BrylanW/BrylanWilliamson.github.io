# Basic Device Hardening Checklist

## Checklist
- Set `enable secret`
- Use strong local usernames and passwords
- Configure SSH and disable Telnet
- Set `service password-encryption`
- Add a login banner
- Configure `exec-timeout`
- Shut down unused interfaces
- Keep IOS updated when possible
- Limit management access with ACLs
- Enable logging and time sync

## Mini review
Hardening reduces attack surface. The goal is to remove unnecessary exposure and secure management access.
