# WPA2 and WPA3

## WPA2
Widely used wireless security standard based on strong encryption.

## WPA3
Adds stronger protections, especially for password-based authentication.

## Best practice
Use the strongest mode supported by your infrastructure and clients.

## Quick note
Avoid outdated protocols such as WEP.
