# Standard ACLs

## What they filter
Standard ACLs filter traffic by **source IP only**.

## Placement rule
Place them as close to the **destination** as possible.

## Example
```cisco
access-list 10 permit 192.168.10.0 0.0.0.255
access-list 10 deny any
interface g0/1
 ip access-group 10 out
```

## Reminder
Every ACL has an implicit `deny any` at the end.
