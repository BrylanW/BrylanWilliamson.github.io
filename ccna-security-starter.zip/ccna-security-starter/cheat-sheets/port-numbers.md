# Port Numbers

| Protocol | Port |
|---|---:|
| FTP | 21 |
| SSH | 22 |
| Telnet | 23 |
| SMTP | 25 |
| DNS | 53 |
| HTTP | 80 |
| POP3 | 110 |
| HTTPS | 443 |
| Syslog | 514 |
