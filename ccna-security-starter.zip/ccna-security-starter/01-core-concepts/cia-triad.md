# CIA Triad

## Definition
The CIA triad is the foundation of information security:
- **Confidentiality**: only authorized users can view data.
- **Integrity**: data is accurate and not tampered with.
- **Availability**: systems and data are accessible when needed.

## Why it matters in networking
A secure network design should protect all three. For example:
- SSH helps confidentiality.
- Checksums and logging support integrity.
- Redundancy and monitoring support availability.

## Example
A router using SSH, strong passwords, and logging helps protect management access and supports auditing.

## Exam Tip
When a question describes “protecting data from unauthorized access,” think confidentiality.
