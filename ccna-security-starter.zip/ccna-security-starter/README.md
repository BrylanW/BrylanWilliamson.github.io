# CCNA Security Notes & Labs

A GitHub-ready starter repository for organizing CCNA Security study notes, configs, and hands-on labs.

## Topics
- Core Concepts
- Network Security Fundamentals
- Device Hardening
- ACLs
- Firewalls and NAT
- VPNs
- Wireless Security
- Monitoring and Logging

## Repository Structure

```text
ccna-security-starter/
├── 01-core-concepts/
├── 02-network-security/
├── 03-device-hardening/
├── 04-acls/
├── 05-firewalls-nat/
├── 06-vpns/
├── 07-wireless-security/
├── 08-monitoring/
├── labs/
├── cheat-sheets/
├── practice-questions/
└── configs/
```

## Suggested Workflow
1. Read a topic note.
2. Add a config example.
3. Build a matching lab.
4. Write down mistakes and fixes.
5. Commit progress to GitHub.

## Progress Tracker
- [ ] Core Concepts
- [ ] Network Security
- [ ] Device Hardening
- [ ] ACLs
- [ ] Firewalls and NAT
- [ ] VPNs
- [ ] Wireless Security
- [ ] Monitoring
- [ ] Labs

## Commit Message Examples
- `add notes for extended ACLs`
- `create SSH hardening lab`
- `update NAT cheat sheet`
- `document port security mistakes`

## License
Use this repo as a personal study template.
