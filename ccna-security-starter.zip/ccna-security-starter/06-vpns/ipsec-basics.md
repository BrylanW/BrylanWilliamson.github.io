# IPsec Basics

## Purpose
IPsec protects IP traffic with encryption and authentication.

## Terms to know
- Confidentiality
- Integrity
- Authentication
- AH
- ESP
- Tunnel mode
- Transport mode

## CCNA focus
Keep it conceptual: why VPNs exist and what IPsec provides.
