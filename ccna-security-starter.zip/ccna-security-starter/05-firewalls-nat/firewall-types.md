# Firewall Types

## Main types
- Packet filtering firewall
- Stateful firewall
- Application-aware firewall
- Next-generation firewall

## Compare
A packet filter checks headers only, while a stateful firewall tracks connection state.

## Cisco angle
For CCNA-level study, understand the idea of stateful inspection and where a firewall fits in network design.
