# Extended ACLs

## What they filter
Extended ACLs can match:
- source IP
- destination IP
- protocol
- port numbers

## Placement rule
Place them as close to the **source** as possible.

## Example
```cisco
access-list 101 deny tcp 192.168.10.0 0.0.0.255 any eq 80
access-list 101 permit ip any any
interface g0/0
 ip access-group 101 in
```

## Common mistakes
- Wrong wildcard mask
- Wrong interface direction
- Forgetting a final permit for allowed traffic
