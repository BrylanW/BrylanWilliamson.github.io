# Types of Attacks

## Common attacks
- **DoS / DDoS**: overwhelm a host or service.
- **Man-in-the-Middle**: intercept traffic between two endpoints.
- **Phishing**: trick users into revealing credentials.
- **Spoofing**: impersonate a device or user.
- **Password attacks**: brute force or dictionary attempts.

## Quick compare
| Attack | Goal | Example |
|---|---|---|
| DoS | Disrupt service | Flooding a web server |
| MITM | Intercept traffic | ARP spoofing on a LAN |
| Phishing | Steal credentials | Fake login page |
| Spoofing | Fake identity | IP or MAC spoofing |

## Common mistake
Mixing up a vulnerability with an attack. A vulnerability is a weakness; an attack exploits it.
