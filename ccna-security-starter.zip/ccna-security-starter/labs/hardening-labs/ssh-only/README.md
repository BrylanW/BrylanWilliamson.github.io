# SSH Only Management Lab

## Objective
Secure remote management by allowing SSH and disabling Telnet.

## Success criteria
- SSH login works
- Telnet fails
- Local login is required
