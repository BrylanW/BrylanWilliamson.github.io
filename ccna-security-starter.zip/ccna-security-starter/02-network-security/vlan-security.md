# VLAN Security

## Key ideas
VLANs improve segmentation, but they do not automatically make a network secure.

## Risks
- VLAN hopping
- Misconfigured trunk ports
- Unused ports left enabled
- Weak native VLAN choices

## Best practices
- Disable unused ports
- Put unused ports in an unused VLAN
- Manually configure trunking
- Change the native VLAN from default
- Use port security where appropriate

## Lab idea
Create two user VLANs and confirm that traffic between them requires Layer 3 routing.
