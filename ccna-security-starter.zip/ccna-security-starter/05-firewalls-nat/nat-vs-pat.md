# NAT vs PAT

## NAT
Network Address Translation changes one IP address to another.

## PAT
Port Address Translation lets many internal hosts share one public IP by tracking unique port numbers.

## Why it matters
PAT is common for internet access in small and medium networks.

## Exam angle
Know the difference between static NAT, dynamic NAT, and PAT.
