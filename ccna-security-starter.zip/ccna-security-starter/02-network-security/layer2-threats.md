# Layer 2 Threats

## Common threats
- MAC flooding
- ARP spoofing
- DHCP starvation
- Rogue DHCP server
- STP manipulation

## Defenses
- Port security
- DHCP snooping
- Dynamic ARP Inspection
- BPDU Guard
- Root Guard

## Exam Tip
Layer 2 attacks are dangerous because they happen inside the LAN where devices often trust each other too much.
