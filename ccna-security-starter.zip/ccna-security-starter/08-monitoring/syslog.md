# Syslog

## Purpose
Syslog collects device messages for monitoring and troubleshooting.

## Why it matters
You can detect failed logins, interface changes, and other security events.

## Basic example
```cisco
service timestamps log datetime msec
logging host 192.168.50.10
logging trap warnings
```

## Good habit
Use NTP so log timestamps are accurate.
