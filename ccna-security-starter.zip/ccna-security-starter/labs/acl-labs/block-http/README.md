# Block HTTP Traffic Lab

## Objective
Block HTTP traffic from a user subnet while allowing other traffic.

## Skills practiced
- Build an extended ACL
- Apply ACL in correct direction
- Verify with show commands and tests

## Files
- `config.txt`
- `notes.md`
- `topology.txt`
