# Secure SSH Config

```cisco
hostname R1
ip domain-name lab.local
username admin secret StrongPass123
crypto key generate rsa modulus 2048
ip ssh version 2
!
line vty 0 4
 login local
 transport input ssh
 exec-timeout 5 0
```

## Why this matters
- Uses local authentication
- Allows SSH only
- Enforces idle session timeout

## Common mistake
Forgetting the domain name before generating RSA keys.
