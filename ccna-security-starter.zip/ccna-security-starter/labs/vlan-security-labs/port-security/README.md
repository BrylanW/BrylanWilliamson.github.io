# Port Security Lab

## Objective
Limit how many MAC addresses can be learned on an access port.

## Skills practiced
- Configure access port mode
- Enable port security
- Set maximum MAC addresses
- Test violation behavior
