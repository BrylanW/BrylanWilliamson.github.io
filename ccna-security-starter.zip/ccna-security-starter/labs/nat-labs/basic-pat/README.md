# Basic PAT Lab

## Objective
Allow multiple inside hosts to reach an outside network using one public IP.

## Skills practiced
- Mark inside and outside interfaces
- Build access list for inside subnet
- Configure PAT overload
