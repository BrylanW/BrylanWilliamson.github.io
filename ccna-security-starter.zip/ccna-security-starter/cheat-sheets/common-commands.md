# Common Commands

## Show commands
```cisco
show running-config
show access-lists
show ip interface brief
show ip ssh
show logging
show port-security interface f0/1
show vlan brief
show interfaces trunk
```

## Troubleshooting habit
Start with interface state, then feature-specific show commands.
